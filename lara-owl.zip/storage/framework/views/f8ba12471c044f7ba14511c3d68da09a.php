<nav class="my-2">
  <ul class="flex flex-row items-center gap-2">
    <li>
      <a class="text-blue-800 dark:text-blue-400 hover:underline" href="<?php echo e(route('dashboard')); ?>">Home</a> </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
      </svg>
    </li>
    <?php if(isset($currentPage) && ($currentPage !== 'Pessoas')): ?>
      <li><a class="text-blue-800 dark:text-blue-400 hover:underline" href="<?php echo e(route('users.index')); ?>">Usuários</a></li>
      <li>
        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
        </svg>
      </li>
    <?php endif; ?>
      <li class="text-gray-400"><?php echo e($currentPage); ?></li>
  </ul>        
</nav><?php /**PATH /var/www/html/resources/views/app/people/partials/breadcrumb.blade.php ENDPATH**/ ?>