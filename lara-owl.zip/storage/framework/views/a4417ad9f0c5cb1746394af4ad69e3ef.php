<?php $__env->startSection('title', 'Detalhe do usuário'); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('admin.users.partials.breadcrumb', ['currentPage' => 'Detalhes do usuário'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="flex flex-col sm:flex-row items-center justify-between">
    <h1 class="text-2xl font-bold my-4 dark:text-zinc-200">Detalhes do usuário</h1>
  </div>

  <ul class="w-full mb-4 border p-4">
    <li class="text-lg h-10"><span class="font-bold">Nome:</span> <?php echo e($user->name); ?></li>
    <li class="text-lg h-10"><span class="font-bold">E-mail:</span> <?php echo e($user->email); ?></li>
  </ul>

  <form action="<?php echo e(route('users.delete', $user->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button class="w-52 rounded-md px-2 h-10 flex items-center justify-center bg-slate-700 dark:bg-slate-500 text-white hover:bg-slate-700/80" type="submit">Excluir</button>
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/users/show.blade.php ENDPATH**/ ?>