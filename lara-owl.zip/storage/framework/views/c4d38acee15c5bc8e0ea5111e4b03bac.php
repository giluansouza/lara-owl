<?php $__env->startSection('title', 'API Access Token'); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('admin.users.partials.breadcrumb', ['currentPage' => 'Token para acessar API'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="flex flex-col sm:flex-row items-center justify-between">
    <h1 class="text-2xl font-bold my-4 dark:text-zinc-200">API token</h1>
  </div>

  <p class="mt-6 mb-2 font-semibold">Token</p>
  <span><?php echo e($token); ?></span>

  <p class="mt-6 mb-2 font-semibold">Testar rotas da API com curl. Exemplo:</p>
  <span>
    curl -X GET http://localhost/api/users \ <br>
    -H "Authorization: Bearer <?php echo e($token); ?>" \ <br>
    -H "Accept: application/json"
  </span>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/users/token.blade.php ENDPATH**/ ?>